package logs;


public interface LogView {
    public void logUpdated(LogBuffer logBuffer);

    public void logUpdated();
}

