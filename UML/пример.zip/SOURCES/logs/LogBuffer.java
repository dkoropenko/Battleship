package logs;

import java.util.ArrayList;

public class LogBuffer extends ArrayList {
    // ���������� �������� � ������
    private int loggedItems;

    public LogBuffer(int initialCapacity) {
        super(initialCapacity);
        loggedItems = 0;
    }

    public LogBuffer() {
        loggedItems = 0;
    }

    public int getLastLogged() {
        return loggedItems;
    }

    public boolean isFullyLogged() {
        return (size() != 0) && (loggedItems == size());
    }

    public void setFullyUpdated() {
        loggedItems = 0;
    }

    public void setFullyLogged() {
        loggedItems = size();
    }
}
