package logs.logatoms;

import ui.LoggingViewArea;

public class LogObjectAtom extends LogAtom {
    final private String objectName;

    public LogObjectAtom(int indent, String objectName) {
        super(indent);
        this.objectName = objectName;
    }


    protected String getMsgContent() {
        return "��� ������� " + objectName + "\n";
    }

    public boolean enabledLogging(LoggingViewArea.LoggingPermissions logPerms) {
        return logPerms.isLoggingObjects();
    }
}
