package logs.logatoms;

import aut.autbase.Automaton;
import event.EnumEvent;
import ui.LoggingViewArea;

public class LogEventAtom extends LogAtom {
    private final Automaton aut;
    private final EnumEvent event;

    public LogEventAtom(int indent, Automaton aut, EnumEvent event) {
        super(indent);
        this.aut = aut;
        this.event = event;
    }

    protected String getMsgContent() {
        if (event == null)
            return new String();
        final String result = "# ������� " + "\"" + aut.getAutID()
                + "\" ��������� �������: "
                + event.toString()
                + "\n";
        return result;
    }

    public boolean enabledLogging(LoggingViewArea.LoggingPermissions logPerms) {
        return logPerms.isLoggingEvents();
    }
}
