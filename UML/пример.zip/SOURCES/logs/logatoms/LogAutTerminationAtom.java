package logs.logatoms;

import aut.autbase.Automaton;
import ui.LoggingViewArea;

public class LogAutTerminationAtom extends LogAtom {
    private final Automaton aut;

    public LogAutTerminationAtom(int indent, final Automaton aut) {
        super(indent);
        this.aut = aut;
    }

    protected String getMsgContent() {
        return "} " + aut.getAutID() + "." + aut.getState().getId() + " (\""
                + aut.getDescirption()
                + "\".\""
                + aut.getState().getDescirption() + "\")\n\n";
    }

    public boolean enabledLogging(LoggingViewArea.LoggingPermissions logPerms) {
        return logPerms.isLoggingAutomatons();
    }
}
