package logs.logatoms;

import aut.autbase.Automaton;
import ui.LoggingViewArea;

public class LogAutRunAtom extends LogAtom {
    private final Automaton aut;

    public LogAutRunAtom(int indent, Automaton aut) {
        super(indent);
        this.aut = aut;
    }

    protected String getMsgContent() {
        return aut.getAutID() + "." + aut.getState().getId() + " (\""
                + aut.getDescirption()
                + "\".\""
                + aut.getState().getDescirption() + "\")" + " {\n";
    }

    public boolean enabledLogging(LoggingViewArea.LoggingPermissions logPerms) {
        return logPerms.isLoggingAutomatons();
    }
}
