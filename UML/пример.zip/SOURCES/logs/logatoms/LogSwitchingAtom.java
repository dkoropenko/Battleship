package logs.logatoms;

import aut.autbase.Automaton;
import ui.LoggingViewArea;

public class LogSwitchingAtom extends LogAtom {
    final private Automaton aut;

    public LogSwitchingAtom(int indent, Automaton automaton) {
        super(indent);
        this.aut = automaton;
    }

    protected String getMsgContent() {
        return aut.getAutID() + "->" + aut.getState().getId() + " (\""
                + aut.getDescirption()
                + "\"->\""
                + aut.getState().getDescirption() + "\")" + "\n";
    }

    public boolean enabledLogging(LoggingViewArea.LoggingPermissions logPerms) {
        return logPerms.isLoggingAutomatons();
    }
}

