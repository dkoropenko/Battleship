package logs.logatoms;

import aut.autbase.Automaton;
import ui.LoggingViewArea;

public class LogVarAtom extends LogAtom {
    private final Automaton.Variable variable;
    private final boolean value;

    public LogVarAtom(int indent, Automaton.Variable variable, boolean value) {
        super(indent);
        this.value = value;
        this.variable = variable;
    }

    protected String getMsgContent() {
        final String strValue = (value) ? "��" : "���";
        final String result = variable.getId() + ": "
                + variable.getDescirption()
                + "? - "
                + strValue
                + "\n";
        return result;
    }

    public boolean enabledLogging(LoggingViewArea.LoggingPermissions logPerms) {
        return logPerms.isLoggingVariables();
    }
}
