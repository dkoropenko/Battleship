package logs.logatoms;

import aut.autbase.Automaton;
import ui.LoggingViewArea;

public class LogActionAtom extends LogAtom {
    private final Automaton.Action action;

    public LogActionAtom(int indent, Automaton.Action action) {
        super(indent);
        this.action = action;
    }

    protected String getMsgContent() {
        return "* " + action.getId() + ": " + action.getDescirption() + "\n";
    }

    public boolean enabledLogging(LoggingViewArea.LoggingPermissions logPerms) {
        return logPerms.isLoggingActions();
    }
}

