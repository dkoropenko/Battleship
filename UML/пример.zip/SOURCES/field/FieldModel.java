package field;


import aut.autbase.Enumerable;

import java.awt.*;

public final class FieldModel {
    private boolean isDisabled = false;

    public static final String ROBOT_FLEET_SIGN = "���� ������";
    public static final String USER_FLEET_SIGN = "���� ������������";

    public final static CellState CSTATE_EMPTY = new CellState("CSTATE_EMPTY");
    public final static CellState CSTATE_SIGHTED = new CellState(
            "CSTATE_SIGHTED");
    public final static CellState CSTATE_FILLED = new CellState(
            "CSTATE_FILLED");
    public final static CellState CSTATE_ATTACKED_EMPTY = new CellState(
            "CSTATE_ATTACKED_EMPTY");
    public final static CellState CSTATE_HINT_ALLOC = new CellState(
            "CSTATE_HINT_ALLOC");
    public final static CellState CSTATE_HINT_EMPTY = new CellState(
            "CSTATE_HINT_EMPTY");
    public final static CellState CSTATE_DISABLED = new CellState(
            "CSTATE_DISABLED");
    public final static CellState CSTATE_HINT_FILLED = new CellState(
            "CSTATE_HINT_FILLED");

    public final static class CellState extends Enumerable {
        private Color color;

        protected CellState(String id) {
            super(id);
            String strColor = getProperty("Color");
            try {
                color = new Color(Integer.parseInt(strColor, 16));
            } catch (NumberFormatException exc) {
                System.err.println(exc.getMessage());
                color = new Color(200, 200, 200);
            }
        }

        public Color getColor() {
            return color;
        }
    }

    private CellState[][] cells;
    private final Dimension fieldSize;  
    private final String fieldName;     
    private Field observer;


    public FieldModel(final String fieldName, final boolean initEnabled) {
        this(null, fieldName, initEnabled, null);
    }

    public FieldModel(final FieldModel model, final boolean initEnabled) {
        this(null, model.getFieldName(), initEnabled, null);

    }

    private FieldModel(final CellState[][] values, final String fieldName,
                       final boolean initEnabled, final Dimension fieldDim) {
        this.fieldSize = (fieldDim != null) ? fieldDim : new Dimension(10, 10);
        this.cells
                = (values != null)
                ? values
                : (
                (initEnabled)
                ? fillVals(CSTATE_EMPTY) : fillVals(CSTATE_DISABLED)
                );
        this.fieldName = fieldName;
    }

    public final String getFieldName() {
        return fieldName;
    }

    public void setObserver(Field field) {
        if (field != null) {
            observer = field;
            observer.update(this);
        }
    }


    public final Dimension getFieldSize() {
        return fieldSize;
    }

    public final CellState getAt(final int row, final int column) {
        return cells[row][column];
    }

    public final void setAt(final int row, final int column,
                            final CellState value) {
        cells[row][column] = value;
        if (observer != null)
            observer.update(this);
    }

    public final int horDim() {
        return (int) fieldSize.getWidth();
    }

    public final int verDim() {
        return (int) fieldSize.getHeight();
    }

    public final void fillWith(final CellState valToFill) {
        cells = fillVals(valToFill);
    }

    private CellState[][] fillVals(final CellState valToFill) {
        final CellState[][] values = new CellState[verDim() + 2][horDim() + 2];
        for (int row = 0; row < horDim() + 2; row++) {
            for (int col = 0; col < verDim() + 2; col++) {
                values[row][col] = valToFill;
            }
        }
        return values;
    }

    public boolean isDisabled() {
        return isDisabled;
    }

    public void setDisabled() {
        isDisabled = true;
        for (int row = 1; row <= horDim(); row++)
            for (int col = 1; col <= verDim(); col++) {
                CellState sellState = getAt(row, col);
                if ((sellState != CSTATE_FILLED) &&
                        (sellState != CSTATE_HINT_FILLED))
                    setAt(row, col, CSTATE_EMPTY);
            }

        if (observer != null)
            observer.update(this);
    }
}
