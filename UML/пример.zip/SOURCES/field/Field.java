package field;

import event.EnumEvent;
import event.EventProvider;
import logics.structs.Point2Dim;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

/**
 * �����, ����������� ��� (view) ��� ������ �������� ���� (FieldModel).
 */
public final class Field extends JComponent {

    private FieldModel model;
    private final FieldMouseListener mouseListener;
    private final FieldMouseMotionListener mouseMotionListener;
    private static final Dimension cellIndent = new Dimension(1, 1);  // ������� �������� ��� ������ ������
    private static final Dimension fieldControlSize = new Dimension(180, 225);  // ������� �������� "����"
    private static final int textHeight = fieldControlSize.height / 7;  // ������ ������� ��� ������� �� ����

    public Field() {
        mouseListener = new FieldMouseListener();
        this.addMouseListener(mouseListener);
        mouseMotionListener = new FieldMouseMotionListener();
        this.addMouseMotionListener(mouseMotionListener);
        this.setPreferredSize(fieldControlSize); // set the preferred size of the control
    }

    private void cleadFieldFromSightedCells() {
        Dimension fieldSize = model.getFieldSize();
        for (int h = 1; h <= fieldSize.getHeight(); h++)
            for (int w = 1; w <= fieldSize.getWidth(); w++)
                if (model.getAt(h, w) == FieldModel.CSTATE_SIGHTED)
                    model.setAt(h, w, FieldModel.CSTATE_EMPTY);
    }

    public final class FieldMouseMotionListener extends MouseMotionAdapter {
        public void mouseMoved(MouseEvent e) {
            super.mouseMoved(e);
            Point2Dim movedPoint = getPressedCell(new Point2Dim(e.getPoint()));
            if (movedPoint.getY() != -1 && movedPoint.getX() != -1) {
                cleadFieldFromSightedCells();
                if ((model.getAt(movedPoint.getY(), movedPoint.getX()) ==
                        FieldModel.CSTATE_EMPTY) &&
                        (getMouseEventProvider() != null) &&
                        (getMouseEventProvider().hasListener()))
                    model.setAt(
                            movedPoint.getY(), movedPoint.getX(),
                            FieldModel.CSTATE_SIGHTED);
            }
        }
    }

    public final class FieldMouseListener extends MouseAdapter {
        final EventProvider provider;

        public FieldMouseListener() {
            provider = new EventProvider();
        }

        public final EventProvider getProvider() {
            return provider;
        }

        public final void mousePressed(final MouseEvent e) {
            super.mousePressed(e);
            Point2Dim pressedPoint = getPressedCell(
                    new Point2Dim(e.getPoint()));
            final EnumEvent event = new event.MouseEvent(pressedPoint);
            provider.eventHappened(event);
        }

        public void mouseExited(MouseEvent e) {
            super.mouseExited(e);
            cleadFieldFromSightedCells();
        }
    }

    public final EventProvider getMouseEventProvider() {
        return mouseListener.getProvider();
    }

    private Point2Dim getPressedCell(final Point2Dim pointClicked) {
        final double x = pointClicked.getX();
        final double y = pointClicked.getY() - textHeight;

        final Dimension controlSize = this.getSize();
        final Dimension fieldDims = model.getFieldSize();
        final double cellWidth = controlSize.width / fieldDims.width;
        final double cellHeight = (controlSize.height - textHeight)
                / fieldDims.height;
        final Point2Dim result = new Point2Dim();

        double box = x / (cellWidth);

        if (box - Math.floor(box) < cellWidth / (cellWidth))
            result.setX((int) Math.ceil(box));
        else
            result.setX(-1);


        box = y / (cellHeight);
        if (box - Math.floor(box) < cellHeight / (cellHeight))
            result.setY((int) Math.ceil(box));
        else
            result.setY(-1);
        return result;
    }

    public final void update(FieldModel fmodel) {
        if (fmodel != null) {
            this.model = fmodel;
            repaint();
        }
    }

    public final void paint(final Graphics g) {
        super.paint(g);
        if (g == null || model == null)
            return;

        g.setFont(new Font("Serif", Font.PLAIN, 17));
        g.drawString(model.getFieldName(), 0, textHeight * 3 / 4);

        final Dimension controlSize = this.getSize();
        final Dimension fieldDims = model.getFieldSize();
        final Dimension cIndent = cellIndent;
        final int cellWidth = controlSize.width / (fieldDims.width)
                - cIndent.width;
        final int cellHeight = (controlSize.height - textHeight)
                / (fieldDims.height)
                - cIndent.height;

        for (int row = 1; row <= fieldDims.getHeight(); row++) {
            for (int col = 1; col <= fieldDims.getWidth(); col++) {
                final int curX = (cIndent.width + cellWidth) * (col - 1);
                final int curY = textHeight
                        + (cIndent.height + cellHeight) * (row - 1);

                g.setColor(model.getAt(row, col).getColor());
                g.fillRect(curX, curY, cellWidth, cellHeight);
                drawSight(g, row, col, curX, curY, cellHeight, cellWidth);
            }
        }
    }

    private void drawSight(Graphics g, int row, int col,
                           int curX, int curY, int cellWidth, int cellHeight) {
        if (model.getAt(row, col) == FieldModel.CSTATE_SIGHTED &&
                !model.isDisabled()) {
            g.setColor(Color.white);
            g.drawOval(
                    curX + cellWidth / 4, curY + cellHeight / 4,
                    cellWidth / 2, cellHeight / 2);
            g.drawOval(curX, curY, cellWidth, cellHeight);

            g.drawLine(
                    curX, curY + cellHeight / 2, curX + cellWidth,
                    curY + cellHeight / 2);
            g.drawLine(
                    curX + cellWidth / 2, curY, curX +
                    cellWidth / 2,
                    curY + cellHeight);
        }
    }

    public FieldModel getModel() {
        return model;
    }
}
