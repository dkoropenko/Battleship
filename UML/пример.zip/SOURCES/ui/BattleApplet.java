package ui;

import javax.swing.*;
import java.awt.*;

/**
 * ������
 */
public class BattleApplet extends JApplet {

    public final void start() {
        BattleMain battle = new BattleMain();
        setSize(new Dimension(600, 480));
        battle.initInterfaceAndAutomatons(getContentPane());
    	doLayout();
    	repaint();        
    }
}
