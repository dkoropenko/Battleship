package ui;

import logs.LogBuffer;
import logs.LogView;
import logs.logatoms.LogAtom;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * �����, ��������� ������� ����������� ����������.
 */
public final class LoggingViewArea extends JScrollPane implements LogView,
        ItemListener, Runnable {

    private LogBuffer logBuffer = null;
    private Thread thread = null;

    public class LoggingPermissions {
        private boolean loggingActions;     // ���������� ��������� �������� �����������
        private boolean loggingVariables;   // ���������� ��������� ������� ����������
        private boolean loggingObjects;     // ���������� ��������� ��������
        private boolean loggingAutomatons;  // ���������� ��������� ���������
        private boolean loggingEvents;      // ���������� ��������� �������

        private void setLoggingActions(final boolean loggingActions) {
            this.loggingActions = loggingActions;
        }

        private void setLoggingVariables(final boolean loggingVariables) {
            this.loggingVariables = loggingVariables;
        }

        private void setLoggingObjects(final boolean loggingObjects) {
            this.loggingObjects = loggingObjects;
        }

        private void setLoggingAutomatons(final boolean loggingAutomatons) {
            this.loggingAutomatons = loggingAutomatons;
        }

        private void setLoggingEvents() {
            this.loggingEvents = loggingVariables || loggingActions;
        }

        public boolean isLoggingActions() {
            return loggingActions;
        }

        public boolean isLoggingEvents() {
            return loggingEvents;
        }

        public boolean isLoggingVariables() {
            return loggingVariables;
        }

        public boolean isLoggingObjects() {
            return loggingObjects;
        }

        public boolean isLoggingAutomatons() {
            return loggingAutomatons;
        }
    };

    private LoggingPermissions logPerms;

    private final JTextArea textArea;
    private String lastStringLogged;

    public LoggingViewArea(final JTextArea textArea) {
        super(textArea);
        logPerms = new LoggingPermissions();
        setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        lastStringLogged = "";

        this.textArea = textArea;
        textArea.setColumns(35);
        textArea.setRows(5);
        textArea.setText("");
        textArea.setFont(new Font("Arial", Font.PLAIN, 11));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
    }

    public final void logUpdated(LogBuffer logBuffer) {
        synchronized (logBuffer) {
            this.logBuffer = logBuffer;
            logBuffer.notify();
        }
    }

    public final void logUpdated() {
        textArea.setText("");

        logBuffer.setFullyUpdated();
        logUpdated(logBuffer);
    }

    public final void start() {
        thread = new Thread(this);
        thread.start();
    }

    public void run() {
        while (thread != null && !thread.isInterrupted()) {
            ArrayList a_tmpList = new ArrayList();
            if (logBuffer != null) {
                synchronized (logBuffer) {
                    for (int i = logBuffer.getLastLogged(); i <
                            logBuffer.size(); i++) {
                        a_tmpList.add(logBuffer.get(i));
                    }
                    if (logBuffer.isFullyLogged()) {
                        try {
                            logBuffer.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        logBuffer.setFullyLogged();
                    }
                }
            }

            StringBuffer logContent = new StringBuffer();
            for (Iterator iterator = a_tmpList.iterator(); iterator.hasNext();) {
                final LogAtom logAtom = (LogAtom) iterator.next();
                final String filteredStr = logAtom.enabledLogging(logPerms)
                        ? logAtom.toString() : "";
                if (filteredStr.equals(lastStringLogged)
                        && filteredStr.trim().equals(""))
                    continue;
                logContent.append(filteredStr);
                lastStringLogged = (filteredStr != "")
                        ? filteredStr : lastStringLogged;
            }
            addString(logContent);
        }
    }

    /**
     * ��������� ������ � ��������.
     */
    private void addString(final StringBuffer str) {
        textArea.append(str.toString());
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
//                textArea.append(str.toString());
                String a_str = textArea.getText();
                if (a_str != null) {
                    try {
                        textArea.setCaretPosition(a_str.length());
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    public final void itemStateChanged(final ItemEvent e) {
        final String name = ((CheckBox) e.getSource()).getName();
        if (name.equals("LogObjects")) {
            logPerms.setLoggingObjects(
                    e.getStateChange() == ItemEvent.SELECTED);
        } else if (name.equals("LogAutomatons")) {
            logPerms.setLoggingAutomatons(
                    e.getStateChange() == ItemEvent.SELECTED);
        } else if (name.equals("LogVaribles")) {
            logPerms.setLoggingVariables(
                    e.getStateChange() == ItemEvent.SELECTED);
        } else if (name.equals("LogActions")) {
            logPerms.setLoggingActions(
                    e.getStateChange() == ItemEvent.SELECTED);
        }
        logPerms.setLoggingEvents();
        if (logBuffer != null) {
            logUpdated();
        }
    }
}