package ui;

import javax.swing.*;

public final class MyCheckBox extends JCheckBox {
    public MyCheckBox(final String text, final boolean selected,
                    final String name) {
        super(text, selected);
        setName(name);
    }
}
