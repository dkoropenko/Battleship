package ui;

import event.ButtonEventProvider;

import javax.swing.*;
import java.awt.*;

public final class ControlsPane extends JPanel {
    private final Button BtnRestart;
    private final Button BtnClearLogs;
    private final CheckBox cbLogObjects;
    private final CheckBox cbLogAuts;
    private final CheckBox cbLogVars;
    private final CheckBox cbLogActs;
    private final ButtonEventProvider btnEventProvider;

    public ButtonEventProvider getBtnEventProvider() {
        return btnEventProvider;
    }

    public final Button getBtnClearLogs() {
        return BtnClearLogs;
    }

    public ControlsPane() {
        setLayout(new GridLayout(7, 1, 0, 5));
        BtnRestart = new Button("Restart", "�������������");
        BtnClearLogs = new Button("ClearLogs", "�������� ����");
        final JLabel label = new JLabel("����:");
        label.setFont(new Font("Serif", Font.PLAIN, 14));

        cbLogObjects = new CheckBox("��������", false, "LogObjects");
        cbLogAuts = new CheckBox("���������", false, "LogAutomatons");
        cbLogVars = new CheckBox("��. ����������", false, "LogVaribles");
        cbLogActs = new CheckBox("���. �����������", false, "LogActions");

        add(label);
        add(cbLogObjects);
        add(cbLogAuts);
        add(cbLogVars);
        add(cbLogActs);
        add(BtnRestart);
        add(BtnClearLogs);

        btnEventProvider = new ButtonEventProvider();
        BtnRestart.addActionListener(btnEventProvider);
    }

    public final CheckBox getCbLogObjects() {
        return cbLogObjects;
    }

    public final CheckBox getCbLogAuts() {
        return cbLogAuts;
    }

    public final CheckBox getCbLogVars() {
        return cbLogVars;
    }

    public final CheckBox getCbLogActs() {
        return cbLogActs;
    }
}
