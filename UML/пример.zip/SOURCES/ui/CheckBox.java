package ui;

import javax.swing.*;

public final class CheckBox extends JCheckBox {
    public CheckBox(final String text, final boolean selected,
                    final String name) {
        super(text, selected);
        setName(name);
    }
}
