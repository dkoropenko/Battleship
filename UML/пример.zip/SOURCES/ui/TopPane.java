package ui;

import field.Field;

import javax.swing.*;
import java.awt.*;

final class TopPane extends JPanel {
    private final Field robotFleet;
    private final Field userFleet;
    private final ControlsPane controls;

    public final ControlsPane getControls() {
        return controls;
    }

    public final Button getClearBtn() {
        return controls.getBtnClearLogs();
    }

    public TopPane(final Field robotFleet, final Field userFleet) {
        super();
        setLayout(new FlowLayout(FlowLayout.LEFT, 15, 0));
        this.robotFleet = robotFleet;
        this.userFleet = userFleet;
        controls = new ControlsPane();
        add(robotFleet);
        add(userFleet);
        add(controls);
    }

    public final Field getRobotFleet() {
        return robotFleet;
    }

    public final Field getUserFleet() {
        return userFleet;
    }
}
