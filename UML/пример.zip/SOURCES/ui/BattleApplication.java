package ui;

import javax.swing.*;

/**
 * ��������� ����������
 */
public class BattleApplication {

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        BattleMain battle = new BattleMain();        
        battle.initInterfaceAndAutomatons(frame.getContentPane());
        frame.setSize(620, 520);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.show();
    }
}
