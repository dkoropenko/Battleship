package ui;

import aut.*;
import event.EventStorage;
import field.Field;
import logs.LoggingModel;

import javax.swing.*;
import java.awt.*;

public final class BattleMain {
    private A0 a0;
    private TopPane topPane;
    private LoggingViewArea logsArea;

    public void initInterfaceAndAutomatons(Container contentPane) {
        contentPane.setLayout(new GridLayout(2, 1));
        topPane = new TopPane(new Field(), new Field());
        contentPane.add(topPane);
        logsArea = new LoggingViewArea(new JTextArea());
        contentPane.add(logsArea);
        final LoggingModel logs = new LoggingModel(logsArea); // �������� ������ ����������������

        logsArea.start(); // ��������� ��������� ����� ��� ��������� ����������

        EventStorage eventStorage = new EventStorage();
// LOGGING CONNECTIONS /BEGIN/

        final A1 a1 = new A1(logs, eventStorage);
        final A2 a2 = new A2(logs, eventStorage);
        final A4 a4 = new A4(logs, eventStorage);
        final A3 a3 = new A3(logs, a4, eventStorage);

// LOGGING CONNECTIONS /END/

// EVENT SOURCE - EVENT SOURCE CONNECTIONS /BEGIN/
        topPane.getControls().getBtnEventProvider().setListener(eventStorage);
        topPane.getControls().getBtnClearLogs().addActionListener(logs);
// EVENT SOURCE - EVENT SOURCE CONNECTIONS /END/

// LOGGING CONTROL CONNECTIONS /BEGIN/
        topPane.getControls().getCbLogActs().addItemListener(logsArea);
        topPane.getControls().getCbLogAuts().addItemListener(logsArea);
        topPane.getControls().getCbLogObjects().addItemListener(logsArea);
        topPane.getControls().getCbLogVars().addItemListener(logsArea);

        topPane.getControls().getCbLogAuts().setSelected(true);
        topPane.getControls().getCbLogObjects().setSelected(true);
        topPane.getClearBtn().addActionListener(logs);
// LOGGING CONTROL CONNECTIONS /END/
        A0ControlledObjects a0ControlledObjects = new
                A0ControlledObjects(topPane.getUserFleet(),
                        topPane.getRobotFleet());
        a0 = new A0(logs, a1, a2, a3, a0ControlledObjects, eventStorage);

        a0.start();
    }
}
