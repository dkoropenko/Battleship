package ui;

import javax.swing.*;
import java.awt.*;

public final class Button extends JButton {
    public Button(final String name, final String text) {
        super(text);
        setName(name);
        setFont(new Font("Dialog", Font.TRUETYPE_FONT, 11));
    }
}
