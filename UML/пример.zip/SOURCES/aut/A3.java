package aut;

import aut.autbase.Automaton;
import event.EnumEvent;
import event.EventStorage;
import event.MouseEvent;
import field.Field;
import field.FieldModel;
import logics.UserAttack;
import logics.structs.Point2Dim;
import logs.LoggingModel;

public final class A3 extends Automaton {
    public final static class State extends Automaton.State {
        private State(String name) {
            super(name);
        }
    }

    public final static class Variable extends Automaton.Variable {
        private Variable(String id) {
            super(id);
        }
    }

    private UserAttack user;
    private final A4 a4;
    private boolean gameOver;

    public final static State INITIAL_STATE = new State("0");
    public final static State UPDATING = new State("1");
    public final static State AWATING_USER_MOVE = new State("2");
    public final static State CHECKING_USER_ACTION = new State("3");
    public final static State ROBOT_MOVE = new State("4");
    public final static State FINAL_STATE = new State("5");

    public static final Variable X90 = new Variable("x90");
    public static final Variable X100 = new Variable("x100");
    public static final Variable X110 = new Variable("x110");

    public final Action Z80;
    public final Action Z90;

    public A3(final LoggingModel logging, final A4 a4, EventStorage storage) {
        super(INITIAL_STATE, logging, storage);
        this.a4 = a4;
        Z80 = new Action("z80", logging) {
            public void doIt() {
                if (!a4.getLogics().enemyIsAlive()) {
                    log.logSection("����� �ᯥ譮 �먣ࠫ �ࠦ����");
                } else if (!user.enemyIsAlive()) {
                    log.logSection("���짮��⥫� �ᯥ譮 �먣ࠫ �ࠦ����");
                }
                gameOver = (!a4.getLogics().enemyIsAlive())
                        || (!user.enemyIsAlive());
                if (gameOver) {
                    a4.getLogics().getFieldModel().setDisabled();
                    user.getFieldModel().setDisabled();
                    user.showRobotFleet();
                }
            }
        };
        Z90 = new Action("z90", logging) {
            public void doIt() {
                final Point2Dim curTarget = user.getCurTarget();
                if (curTarget.getX() != -1 && curTarget.getY() != -1)
                    user.strike(curTarget.getY(), curTarget.getX());
            }
        };
    }

    public final void setUser(final UserAttack user) {
        this.user = user;
    }

    protected final Automaton.State nextState() {
        final Automaton.State y3 = getState();
        Automaton.State resultState = getState();
        EnumEvent eTypes[] = {EnumEvent.EVENT_GAME_RESET,
                              EnumEvent.EVENT_MOUSE_CLICKED};

        if (y3 == INITIAL_STATE) {
            resultState = UPDATING;
        } else if (y3 == UPDATING) {
            if (x90())
                resultState = FINAL_STATE;
            else
                resultState = AWATING_USER_MOVE;
        } else if (y3 == AWATING_USER_MOVE) {
            final EnumEvent event = waitForEvents(eTypes);
            if (eventToPos(event)) {
                resultState = CHECKING_USER_ACTION;
            } else if ((event != null)
                    && event.equals(EnumEvent.EVENT_GAME_RESET)) {
                setFailed();
                resultState = awaitingState;
            }
        } else if (y3 == CHECKING_USER_ACTION) {
            if (x110())
                resultState = AWATING_USER_MOVE;
            else {
                if (x100())
                    resultState = UPDATING;
                else
                    resultState = ROBOT_MOVE;
            }
        } else if (y3 == ROBOT_MOVE) {
            a4.start(A4.CHECKING_ENEMY, A4.FINAL_STATE);
            resultState = UPDATING;
        }

        if (UPDATING == resultState)
            Z80.perform();
        else if (CHECKING_USER_ACTION == resultState)
            Z90.perform();
        return resultState;
    }

    private boolean x100() {
        final boolean result = user.getStrikeResult();
        log.logVariable(X100, result);
        return result;
    }

    private boolean x110() {
        final Point2Dim curTarget = user.getCurTarget();

        final boolean result = (curTarget.getY() < 1)
                || (curTarget.getY() > user.verDim())
                || (curTarget.getX() < 1)
                || (curTarget.getX() > user.horDim());
        log.logVariable(X110, result);
        return result;
    }

    private boolean x90() {
        log.logVariable(X90, gameOver);
        return gameOver;
    }

    private boolean eventToPos(final EnumEvent event) {
        log.logEvent(this, event);
        if (event == null ||
                ((event != null) && event.equals(EnumEvent.EVENT_GAME_RESET)) ||
                ((MouseEvent) event).getPoint() == null)
            return false;
        user.setCurTarget(((MouseEvent) event).getPoint());
        return true;
    }

    public void initiateLogics(FieldModel userField) {
        a4.initiateLogics(userField);
    }

    public void setUserFieldView(Field userFieldView) {
        a4.getLogics().getFieldModel().setObserver(userFieldView);
    }
}