package aut;

import aut.autbase.Automaton;
import event.EventStorage;
import field.FieldModel;
import logics.AutoAttack;
import logics.structs.Point2Dim;
import logs.LoggingModel;

/**
 * <code>A4</code> ���������� ������ �������������� ���������������� ��������
 * ����� �������. �� ����� ��������� ���������.
 */
public final class A4 extends Automaton {
    /**
     * <code>State</code> ������������ ��������� ��������.
     */
    public final static class State extends Automaton.State {
        private State(String name) {
            super(name);
        }
    }

    /**
     * <code>Variable</code> ������������ ������� ���������� ��������.
     */
    public final static class Variable extends Automaton.Variable {
        private Variable(String id) {
            super(id);
        }
    }

    private AutoAttack logics;
    private boolean strikeRes;
    private Point2Dim curTargPos;

    public final static State CHECKING_ENEMY = new State("0");
    public final static State CHECKING_FIELD = new State("1");
    public final static State COMPLETING_ATTACK = new State("2");
    public final static State NEW_ATTACK = new State("3");
    public final static State FINAL_STATE = new State("4");

    public static final Variable X130 = new Variable("x130");
    public static final Variable X140 = new Variable("x140");
    public static final Variable X150 = new Variable("x150");
    public static final Variable X160 = new Variable("x160");

    public final Action Z120;
    public final Action Z125;
    public final Action Z130;

    public final void initiateLogics(final FieldModel field) {
        logics = new AutoAttack(field);
    }

    public A4(final LoggingModel logging, EventStorage storage) {
        super(CHECKING_ENEMY, logging, storage);
        Z120 = new Action("z120", logging) {
            public void doIt() {
                curTargPos = logics.haveTarget();
            }
        };
        Z125 = new Action("z125", logging) {
            public void doIt() {
                curTargPos = logics.getRandTarget();
            }
        };

        Z130 = new Action("z130", logging) {
            public void doIt() {
                if (curTargPos != null)
                    strikeRes
                            = logics.strike(
                                    curTargPos.getY(), curTargPos.getX()
                            );
            }
        };
    }

    protected final Automaton.State nextState() {
        Automaton.State resultState = getState();
        final Automaton.State y4 = getState();

        if (y4 == CHECKING_ENEMY) {
            if (!x140()) {
                resultState = CHECKING_FIELD;
            } else
                resultState = FINAL_STATE;
        } else if (y4 == CHECKING_FIELD) {
            if (x150()) {
                resultState = COMPLETING_ATTACK;
            } else {
                if (x140() || x160()) {
                    resultState = FINAL_STATE;
                } else {
                    resultState = NEW_ATTACK;
                }
            }
        } else if (y4 == COMPLETING_ATTACK) {
            if (x130())
                resultState = CHECKING_FIELD;
            else
                resultState = FINAL_STATE;
        } else if (y4 == NEW_ATTACK) {
            if (x130())
                resultState = CHECKING_FIELD;
            else
                resultState = FINAL_STATE;
        }

        if (CHECKING_FIELD == resultState)
            Z120.perform();
        else if (COMPLETING_ATTACK == resultState)
            Z130.perform();
        else if (NEW_ATTACK == resultState) {
            Z125.perform();
            Z130.perform();
        }

        return resultState;
    }

    private boolean x160() {
        final boolean result = !logics.checkAlloc(logics.getMaxTarget());
        log.logVariable(X160, result);
        return result;
    }

    private boolean x150() {
        final boolean result = (curTargPos != null);
        log.logVariable(X150, result);
        return result;
    }

    private boolean x140() {
        final boolean result = logics.getMaxTarget() == 0;
        log.logVariable(X140, result);
        return result;
    }

    private boolean x130() {
        log.logVariable(X130, strikeRes);
        return strikeRes;
    }

    final AutoAttack getLogics() {
        return logics;
    }
}
