package aut;

import aut.autbase.Automaton;
import event.EventStorage;
import field.FieldModel;
import logics.AutoAllocation;
import logics.structs.OrientedPoint;
import logics.structs.Ship;
import logs.LoggingModel;

/**
 * <code>A2</code> ������������ ����� ���������� ����� ��������������
 * ����������� �������� �������. �� ����� ��������� ���������.
 */
public final class A2 extends Automaton {

    /**
     * <code>State</code> ������������ ��������� ��������.
     */
    public final static class State extends Automaton.State {
        private State(String name) {
            super(name);
        }
    }

    /**
     * <code>Variable</code> ������������ ������� ���������� ��������.
     */
    public final static class Variable extends Automaton.Variable {
        private Variable(String id) {
            super(id);
        }
    }

    private AutoAllocation logics;
    private Ship curFigure;

    public final static State INITIAL_STATE = new State("0");
    public final static State CHOOSING_SHIP_TYPE = new State("1");
    public final static State CHECKING_FIELD = new State("2");
    public final static State SHIP_SETUP = new State("3");
    public final static State FINAL_STATE = new State("4");

    public static final Variable X50 = new Variable("x50");
    public static final Variable X60 = new Variable("x60");
    public static final Variable X70 = new Variable("x70");

    public final Action Z45;
    public final Action Z50;
    public final Action Z60;

    public final void initiateLogics(final FieldModel field) {
        logics = new AutoAllocation(field);
    }

    public A2(final LoggingModel logging, EventStorage storage) {
        super(INITIAL_STATE, logging, storage);
        Z45 = new Action("z45", logging) {
            public void doIt() {
                logics.getFieldModel().fillWith(FieldModel.CSTATE_EMPTY);
            }
        };
        Z50 = new Action("z50", logging) {
            public void doIt() {
                final OrientedPoint pos = logics.getAllocation(
                        curFigure.getLength());
                curFigure.setPosition(pos);
                logics.putShip(curFigure);
            }
        };
        Z60 = new Action("z60", logging) {
            public void doIt() {
                curFigure = logics.getUnalloc();
            }
        };
    }

    protected final Automaton.State nextState() {
        final Automaton.State y2 = getState();
        A2.State resultState = FINAL_STATE;

        if (y2 == INITIAL_STATE) {
            Z45.perform();
            resultState = CHOOSING_SHIP_TYPE;
        } else if (y2 == CHOOSING_SHIP_TYPE) {
            if (x70())
                resultState = CHECKING_FIELD;
            else {
                resultState = FINAL_STATE;
            }
        } else if (y2 == CHECKING_FIELD) {
            if (x50()) {
                resultState = SHIP_SETUP;
            } else {
                resultState = FINAL_STATE;
            }
        } else if (y2 == SHIP_SETUP) {
            if (x60())
                resultState = CHOOSING_SHIP_TYPE;
            else
                resultState = FINAL_STATE;
        }


        if (CHOOSING_SHIP_TYPE == resultState)
            Z60.perform();
        else if (SHIP_SETUP == resultState)
            Z50.perform();

        return resultState;
    }

    private boolean x60() {
        final boolean result = (curFigure != null) && curFigure.isAllocated();
        log.logVariable(X60, result);
        return result;
    }

    private boolean x50() {
        final boolean result = logics.checkAlloc(curFigure.getLength());
        log.logVariable(X50, result);
        return result;
    }

    private boolean x70() {
        final boolean result = (curFigure != null)
                && (curFigure.getLength() > 0);
        log.logVariable(X70, result);
        return result;
    }

    final Object getLogics() {
        return logics;
    }
}
