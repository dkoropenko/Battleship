package aut;

import aut.autbase.Automaton;
import event.EnumEvent;
import event.EventStorage;
import field.FieldModel;
import logics.AutoAllocation;
import logics.UserAttack;
import logs.LoggingModel;


public final class A0 extends Automaton {
    public final static class State extends Automaton.State {
        private State(String name) {
            super(name);
        }
    }

    public final static State INITIAL_STATE = new State("0");
    public final static State USER_SHIPS_ALLOC = new State("1");
    public final static State COMP_SHIPS_ALLOC = new State("2");
    public final static State BATTLE = new State("3");
    public final static State FINAL_STATE = new State("4");

    final static EnumEvent eTypes[] = {EnumEvent.EVENT_GAME_RESET};

    public final Action Z0;
    public final Action Z2;

    private final A1 a1;
    private final A2 a2;
    private final A3 a3;

    private A0ControlledObjects controlledObjects;

    public A0(LoggingModel log, A1 a1, A2 a2, A3 a3,
              A0ControlledObjects controlledObjects,
              EventStorage eventStorage) {
        super(INITIAL_STATE, log, eventStorage);
        this.a1 = a1;
        this.a2 = a2;
        this.a3 = a3;
        this.controlledObjects = controlledObjects;

        Z0 = new Action("z0", log) {
            public void doIt() {
                initAllocation();
            }
        };

        Z2 = new Action("z5", log) {
            public void doIt() {
                initBattle();
            }
        };
    }

    protected final Automaton.State nextState() {
        final Automaton.State y0 = getState();
        Automaton.State resultState = getState();


        if (INITIAL_STATE == y0) {
            log.logSection("����⠭���� 䨣�� ���짮��⥫�");
            Z0.perform();
            resultState = USER_SHIPS_ALLOC;
        } else if (USER_SHIPS_ALLOC == y0) {
            a1.start(A1.INITIAL_STATE, A1.FINAL_STATE);
            if (!a1.succeeded()) {
                resultState = INITIAL_STATE;
            } else {
                log.logSection("����⠭����  䨣�� �����");
                resultState = COMP_SHIPS_ALLOC;
            }
        } else if (COMP_SHIPS_ALLOC == y0) {
            a2.start(A2.INITIAL_STATE, A2.FINAL_STATE);
            if (!a2.succeeded()) {
                resultState = INITIAL_STATE;
            } else {
                log.logSection("�ࠦ����");
                resultState = BATTLE;
            }
        } else if (BATTLE == y0) {
            a3.start(A3.INITIAL_STATE, A3.FINAL_STATE);
            if (!a3.succeeded()) {
                resultState = INITIAL_STATE;
            } else {
                log.logSection("����� ����");
                resultState = FINAL_STATE;
            }
        } else if (FINAL_STATE == y0) {
            final EnumEvent event = waitForEvents(eTypes);
            if (event != null) {
                resultState = INITIAL_STATE;
                eventStorage.clean(); // clean event storage
            }
        }

        if (COMP_SHIPS_ALLOC == resultState) {
            Z2.perform();
        }
        return resultState;
    }

    private void initAllocation() {
        final FieldModel robotField =
                new FieldModel(FieldModel.ROBOT_FLEET_SIGN, false); // initEnabled = false
        final FieldModel emptyField =
                new FieldModel(FieldModel.ROBOT_FLEET_SIGN, false); // initEnabled = false

        final FieldModel userField =
                new FieldModel(FieldModel.USER_FLEET_SIGN, true); // initEnabled = true

        a1.initiateLogics(userField);
        a2.initiateLogics(robotField);

        getEventStorage().clean();

        userField.setObserver(controlledObjects.getUserFieldView());
        emptyField.setObserver(controlledObjects.getRobotFieldView());

        // don't allow user to listen to the mouse
        controlledObjects.setUserFieldListener(getEventStorage());
        // make robot field listen to the mouse events
        controlledObjects.setRobotFieldListener(null);
    }

    private void initBattle() {
        getEventStorage().clean();

        final FieldModel userField =
                controlledObjects.getUserFieldView().getModel();
        final FieldModel robotField = ((AutoAllocation) a2.getLogics()).getFieldModel();

        final UserAttack userAttack = new UserAttack(robotField);

        a3.initiateLogics(userField);
        a3.setUser(userAttack);

        userAttack.getFieldModel().setObserver(
                controlledObjects.getRobotFieldView());
        a3.setUserFieldView(controlledObjects.getUserFieldView());

        controlledObjects.setUserFieldListener(null);
        controlledObjects.setRobotFieldListener(getEventStorage());
    }
}
