package aut;

import event.ProviderListener;
import field.Field;

public class A0ControlledObjects {

    private Field userFieldView;
    private Field robotFieldView;

    public A0ControlledObjects(Field userFieldView, Field robotFieldView) {
        this.userFieldView = userFieldView;
        this.robotFieldView = robotFieldView;
    }

    public Field getUserFieldView() {
        return userFieldView;
    }

    public Field getRobotFieldView() {
        return robotFieldView;
    }

    public void setUserFieldListener(ProviderListener listener) {
        userFieldView.getMouseEventProvider().setListener(listener);
    }

    public void setRobotFieldListener(ProviderListener listener) {
        robotFieldView.getMouseEventProvider().setListener(listener);
    }
}
