package event;

public interface ProviderListener {
    /**
     * this method is the processing of the event appearence
     *
     * @param event is the event to be processed
     */
    public void addEvent(EnumEvent event);
}
