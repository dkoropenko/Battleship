package logics;

import field.FieldModel;
import logics.structs.OrientedPoint;
import logics.structs.Point2Dim;

/**
 * ����� �������������� �����.
 */
public final class AutoAttack extends Attack {

    public AutoAttack(final FieldModel enemy) {
        super(enemy);

        for (int row = 0; row < verDim + 2; row++) {
            for (int col = 0; col < horDim + 2; col++) {
                if (enemy.getAt(row, col) == FieldModel.CSTATE_FILLED)
                    fieldModel.setAt(row, col, FieldModel.CSTATE_HINT_FILLED);
            }
        }
    }

    public final int getMaxTarget() {
        for (int t = 3; t >= 0; t--)
            if (targets[t] < 4 - t)
                return (t + 1);
        return 0;
    }

    /**
     * ���������� ��������� ��������� ����������� �������.
     */
    public final Point2Dim getRandTarget() {
        final OrientedPoint pos = getRandomPos(getMaxTarget());
        return new Point2Dim(pos.getX(), pos.getY());
    }

    /**
     * ���������� ��������� ���������� ���� ��� ������� ������������� �����.
     */
    public final Point2Dim haveTarget() {
        final Point2Dim target = new Point2Dim();
        final int[][] targs = new int[verDim + 2][horDim + 2];

        for (int row = 0; row < verDim + 2; row++)
            for (int col = 0; col < horDim + 2; col++)
                targs[row][col] = 0;

        int targsNum = 0;

        for (int row = 1; row <= verDim; row++) {
            for (int col = 1; col <= horDim; col++) {
                if (fieldModel.getAt(row, col) == FieldModel.CSTATE_FILLED) {
                    if ((
                            (
                            fieldModel.getAt(row - 1, col)
                            == FieldModel.CSTATE_EMPTY
                            )
                            || (
                            fieldModel.getAt(row - 1, col)
                            == FieldModel.CSTATE_HINT_FILLED
                            )
                            )
                            && (row > 1)) {
                        targsNum++;
                        targs[row - 1][col] = 1;
                    }

                    if ((
                            (
                            fieldModel.getAt(row + 1, col)
                            == FieldModel.CSTATE_EMPTY
                            )
                            || (
                            fieldModel.getAt(row + 1, col)
                            == FieldModel.CSTATE_HINT_FILLED
                            )
                            )
                            && (row < verDim)) {
                        targsNum++;
                        targs[row + 1][col] = 1;
                    }

                    if ((
                            (
                            fieldModel.getAt(row, col - 1)
                            == FieldModel.CSTATE_EMPTY
                            )
                            || (
                            fieldModel.getAt(row, col - 1)
                            == FieldModel.CSTATE_HINT_FILLED
                            )
                            )
                            && (col > 1)) {
                        targsNum++;
                        targs[row][col - 1] = 1;
                    }

                    if ((
                            (
                            fieldModel.getAt(row, col + 1)
                            == FieldModel.CSTATE_EMPTY
                            )
                            || (
                            fieldModel.getAt(row, col + 1)
                            == FieldModel.CSTATE_HINT_FILLED
                            )
                            )
                            && (col < horDim)) {
                        targsNum++;
                        targs[row][col + 1] = 1;
                    }
                }
            }
        }

        if (targsNum == 0)
            return null;

        final int rn = (int) Math.ceil(Math.random() * (targsNum - 1) + 1);
        int count = 0;

        for (int row = 1; row <= verDim; row++)
            for (int col = 1; col <= horDim; col++)
                if (targs[row][col] == 1) {
                    count++;
                    if (count == rn) {
                        target.setLocation(col, row);
                        return target;
                    }
                }

        return null;
    }
}
