package logics;

import field.FieldModel;
import logics.structs.OrientedPoint;

public final class AutoAllocation extends Allocation {
    public AutoAllocation(final FieldModel fieldModel) {
        super(fieldModel);
    }

    public final OrientedPoint getAllocation(final int length) {
        return getRandomPos(length);
    }
}
