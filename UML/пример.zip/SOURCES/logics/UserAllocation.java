package logics;

import field.FieldModel;
import logics.structs.OrientedPoint;
import logics.structs.Point2Dim;

/**
 * ����� ����������� �������� ������������.
 */
public final class UserAllocation extends Allocation {

    public UserAllocation(final FieldModel fieldModel) {
        super(fieldModel);
    }

    public final boolean directFit(final OrientedPoint pos, final int length) {
        if (pos.isHorisontallyOriented())
            if (auxField[0][pos.getY()][pos.getX()] >= length)
                return true;
        if (pos.isVerticallyOriented())
            if (auxField[1][pos.getY()][pos.getX()] >= length)
                return true;
        return false;
    }

    public final boolean posFit(final Point2Dim p, final int length) {
        if ((auxField[0][p.getY()][p.getX()] >= length)
                || (auxField[1][p.getY()][p.getX()] >= length))
            return true;

        return false;
    }
}
