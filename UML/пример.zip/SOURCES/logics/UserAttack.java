package logics;

import field.FieldModel;
import logics.structs.Point2Dim;

/**
 * ����� ����� ������.
 */
public final class UserAttack extends Attack {
    private boolean strikeResult;
    private Point2Dim curTarget;

    public UserAttack(final FieldModel enemy) {
        super(enemy);
    }

    public final boolean strike(final int y, final int x) {
        strikeResult = super.strike(y, x);
        return strikeResult;
    }

    public final boolean getStrikeResult() {
        return strikeResult;
    }

    public final Point2Dim getCurTarget() {
        return curTarget;
    }

    public final void setCurTarget(final Point2Dim curTarget) {
        this.curTarget = curTarget;
    }

    public void showRobotFleet() {
        for (int row = 0; row < verDim + 2; row++) {
            for (int col = 0; col < horDim + 2; col++) {
                if ((enemyMap.getAt(row, col) == FieldModel.CSTATE_FILLED) &&
                        (fieldModel.getAt(row, col) == FieldModel.CSTATE_EMPTY))
                    fieldModel.setAt(row, col, FieldModel.CSTATE_HINT_FILLED);
            }
        }
    }
}
