package logics;

import field.FieldModel;

/**
 * ������� ����� ��� ����������.
 */
public class Attack extends BaseProcessor {
    int[] targets;
    protected final FieldModel enemyMap;

    public Attack(final FieldModel enemy) {
        super(new FieldModel(enemy, true));
        this.enemyMap = enemy;
        initAttack();
    }

    private void initAttack() {
        targets = new int[4];
    }

    /**
     * ��������� "����������������" ����������.
     */
    public final boolean enemyIsAlive() {
        for (int t = 0; t < 4; t++) {
            if (targets[t] < 4 - t)
                return true;
        }
        return false;
    }

    /**
     * ���������� ����� ������������������ ������� ������ � ����� �����.
     */
    private int getTargetLength(final int y, final int x,
                                final FieldModel field) {

        if (field.getAt(y, x) != FieldModel.CSTATE_FILLED) {
            return 0;
        }

        final boolean isLevel;
        int length = 0;

        if ((field.getAt(y + 1, x) == FieldModel.CSTATE_FILLED)
                || (field.getAt(y - 1, x) == FieldModel.CSTATE_FILLED))
            isLevel = false;
        else {
            if ((field.getAt(y, x + 1) == FieldModel.CSTATE_FILLED)
                    || (field.getAt(y, x - 1) == FieldModel.CSTATE_FILLED))
                isLevel = true;
            else
                return 1;
        }

        if (isLevel) // ���� ���� ������������� �������������
        {
            int col = x;
            while ((field.getAt(y, col - 1) == FieldModel.CSTATE_FILLED)
                    && (col > 1))
                col--;

            while ((field.getAt(y, col) == FieldModel.CSTATE_FILLED)
                    && (col <= horDim)) {
                col++;
                length++;
            }
        } else        // ���� ���� ������������� �����������
        {
            int row = y;
            while ((field.getAt(row - 1, x) == FieldModel.CSTATE_FILLED)
                    && (row > 1))
                row--;

            while ((field.getAt(row, x) == FieldModel.CSTATE_FILLED)
                    && (row <= verDim)) {
                row++;
                length++;
            }
        }
        return length;
    }

    /**
     * �������� ��� �������� � �������� ������, ��� �������������,
     * ����� �� ������ ������ ������.
     */
    private void markTarget(final int y, final int x, final boolean finished) {
        if (fieldModel.getAt(y, x) != FieldModel.CSTATE_FILLED)
            return;
        final boolean isLevel;

        if ((fieldModel.getAt(y + 1, x) == FieldModel.CSTATE_FILLED)
                || (fieldModel.getAt(y - 1, x) == FieldModel.CSTATE_FILLED))
            isLevel = false;
        else {
            if ((fieldModel.getAt(y, x + 1) == FieldModel.CSTATE_FILLED)
                    ||
                    (fieldModel.getAt(y, x - 1) == FieldModel.CSTATE_FILLED))
                isLevel = true;
            else // � ������ ��������� ����� �������
            {
                for (int i = -1; i < 2; i++) {
                    for (int j = -1; j < 2; j++) {
                        if ((
                                finished && ((i != 0) || (j != 0))
                                || ((!finished) && ((i != 0) && (j != 0)))
                                ))
                            setCellState(
                                    y + i, x + j, FieldModel.CSTATE_HINT_EMPTY);
                    }
                }
                return;
            }
        }

        if (isLevel) {
            int col = x;
            while ((fieldModel.getAt(y, col - 1) == FieldModel.CSTATE_FILLED)
                    && (col > 1))
                col--;

            setCellState(y + 1, col - 1, FieldModel.CSTATE_HINT_EMPTY);
            setCellState(y - 1, col - 1, FieldModel.CSTATE_HINT_EMPTY);

            if (finished)
                setCellState(y, col - 1, FieldModel.CSTATE_HINT_EMPTY);

            while ((fieldModel.getAt(y, col) == FieldModel.CSTATE_FILLED)
                    && (col <= horDim)) {
                setCellState(y - 1, col, FieldModel.CSTATE_HINT_EMPTY);
                setCellState(y + 1, col, FieldModel.CSTATE_HINT_EMPTY);
                col++;
            }

            setCellState(y - 1, col, FieldModel.CSTATE_HINT_EMPTY);
            setCellState(y + 1, col, FieldModel.CSTATE_HINT_EMPTY);
            if (finished)
                setCellState(y, col, FieldModel.CSTATE_HINT_EMPTY);
        } else {

            int row = y;
            while ((fieldModel.getAt(row - 1, x) == FieldModel.CSTATE_FILLED)
                    && (row > 1))
                row--;

            setCellState(row - 1, x - 1, FieldModel.CSTATE_HINT_EMPTY);
            setCellState(row - 1, x + 1, FieldModel.CSTATE_HINT_EMPTY);

            if (finished)
                setCellState(row - 1, x, FieldModel.CSTATE_HINT_EMPTY);

            while ((fieldModel.getAt(row, x) == FieldModel.CSTATE_FILLED)
                    && (row <= verDim)) {
                setCellState(row, x - 1, FieldModel.CSTATE_HINT_EMPTY);
                setCellState(row, x + 1, FieldModel.CSTATE_HINT_EMPTY);
                row++;
            }

            setCellState(row, x - 1, FieldModel.CSTATE_HINT_EMPTY);
            setCellState(row, x + 1, FieldModel.CSTATE_HINT_EMPTY);

            if (finished)
                setCellState(row, x, FieldModel.CSTATE_HINT_EMPTY);
        }
    }

    public boolean strike(final int y, final int x) {
        if (enemyMap.getAt(y, x) == FieldModel.CSTATE_EMPTY)
            setCellState(y, x, FieldModel.CSTATE_ATTACKED_EMPTY);

        if ((fieldModel.getAt(y, x) == FieldModel.CSTATE_FILLED)
                || (enemyMap.getAt(y, x) == FieldModel.CSTATE_EMPTY))
            return false;

        setCellState(y, x, FieldModel.CSTATE_FILLED);
        if (getTargetLength(y, x, fieldModel)
                == getTargetLength(y, x, enemyMap)) {
            targets[getTargetLength(y, x, fieldModel) - 1]++;
            markTarget(y, x, true);
        } else
            markTarget(y, x, false);
        return true;
    }
}
